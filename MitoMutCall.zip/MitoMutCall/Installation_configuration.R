#####Install packages 'MitoMutCall'####
lib.install.path=.libPaths()[1]
lib.install.path2=paste("~/R/x86_64-pc-linux-gnu-library/",version$major,".",strsplit(version$minor,split=".",fixed=TRUE)[[1]][1],sep="")
if(length(tryCatch(install.packages("MitoMutCall.tar.gz"),error=function(w){FALSE},error=function(e){FALSE}))!=0){
if(tryCatch(install.packages("MitoMutCall.tar.gz"),error=function(w){FALSE},error=function(e){FALSE})==FALSE){lib.install.path=lib.install.path2}
}
if(!requireNamespace("MitoMutCall",quietly=TRUE) & !file.exists(paste(lib.install.path2,"/MitoMutCall",sep=""))){
if(lib.install.path==lib.install.path2){
print("The user is a regular user. It will install packages in personal path")
system("mkdir ~/R")
system("mkdir ~/R/x86_64-pc-linux-gnu-library/")
system(paste("mkdir ",lib.install.path,sep=""))
}
install.packages("MitoMutCall.tar.gz",lib=lib.install.path)
lib.install.path3=lib.install.path
}else{lib.install.path3=.libPaths()[1]}
#####Install packages 'MitoMutCall'####
#####Update the require sofewares of 'bwa/samtools/bedtools' configuration#####
args<-commandArgs(T)
if(lib.install.path3==.libPaths()[1]){tools_path=paste(installed.packages()["MitoMutCall",c('LibPath')],"MitoMutCall",sep="/")}else{tools_path=paste(lib.install.path2,"/MitoMutCall",sep="")}
for(tools in args){
system(paste("cp -f ",tools," ",tools_path,sep=""))
}
#####Update configuration of 'bwa/samtools' #####
#####Install initial configuration of 'bwa/samtools'#####
bwa_path=paste(tools_path,"bwa",sep="/")
samtools_path=paste(tools_path,"samtools",sep="/")
if(!file.exists(bwa_path)){system(paste("cd ./bwa; make; cp -f bwa ",tools_path,"; cd ..",sep=""))}
if(!file.exists(samtools_path)){system(paste("cd ./htslib; make; cd ../samtools; make; cp -f samtools ",tools_path,"; cd ..",sep=""))}
#####Install initial configuration of 'bwa/samtools'#####
#####Check and install require R packges####
for(pkg in c("Biostrings","data.table","parallel","stringr","plyr","reshape2")){
    if(!requireNamespace(pkg,quietly=TRUE) & !file.exists(paste(lib.install.path2,"/",pkg,sep=""))){
      print(paste("Please maintain your network connection to install ",pkg,sep=""))
      if(pkg=="Biostrings"){
      if(as.numeric(paste(version$major,strsplit(version$minor,split=".",fixed=TRUE)[[1]][1],sep="."))<3.5){
      source("http://bioconductor.org/biocLite.R")
      biocLite("Biostrings",lib=lib.install.path)
      }else{install.packages("BiocManager",lib=lib.install.path,repos = "https://CRAN.R-project.org/");library("BiocManager",lib=lib.install.path);BiocManager::install("Biostrings", version = "3.8",lib=lib.install.path)}}
      if(pkg=="data.table"){install.packages("data.table",lib=lib.install.path,repos = "https://CRAN.R-project.org/")}
      if(pkg=="parallel"){install.packages("parallel",lib=lib.install.path,repos = "https://CRAN.R-project.org/")}
      if(pkg=="stringr"){install.packages("stringr",lib=lib.install.path,repos = "https://CRAN.R-project.org/")}
      if(pkg=="plyr"){install.packages("plyr",lib=lib.install.path,repos = "https://CRAN.R-project.org/")}
      if(pkg=="reshape2"){install.packages("reshape2",lib=lib.install.path,repos = "https://CRAN.R-project.org/")}
      if(!requireNamespace(pkg,quietly=TRUE)& !file.exists(paste(lib.install.path2,"/",pkg,sep=""))){warning(paste("The installation of package '",pkg,"' failed. Please try other installation methods",sep=""))}else{print(paste("Successfully installed the require package '",pkg,"'",sep=""))}
    }else{print(paste("The required package '",pkg,"' has been installed",sep=""))}
  }
#####Check and install require R packges####
